
import random

# ************
# nazwa funkcji: generuj_haslo
# opis funkcji: generuje losowe haslo i je wyswietla
# paramtery: brak
# zwracany typ: brak
# autor: JJ
# ************
def generuj_haslo():
    male_litery = "abcdefghijklmnopqrstuvwxyz"
    duze_litery = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    polskie_znaki = "ąęłńóśźżĄĘŁŃÓŚŹŻ"
    cyfry = "0123456789"
    znaki_specjalne = "!@#$%^&*()_+"

    haslo = []

    for i in range(3):
        haslo.append(random.choice(male_litery))

    for i in range(3):
        haslo.append(random.choice(duze_litery))

    for i in range(2):
        haslo.append(random.choice(polskie_znaki))

    for i in range(2):
        haslo.append(random.choice(cyfry))

    for i in range(2):
        haslo.append(random.choice(znaki_specjalne))

    random.shuffle(haslo)
    return "".join(haslo)


def main():
    print("====================================")
    print("       GENERATOR BEZPIECZNYCH HASŁ")
    print("====================================")

    for i in range(5):
        haslo = generuj_haslo()
        print(f"Hasło nr {i + 1}: {haslo}")

    print("====================================")
    print("Wygenerowano 5 bezpiecznych haseł.")


if __name__ == "__main__":
    main()
